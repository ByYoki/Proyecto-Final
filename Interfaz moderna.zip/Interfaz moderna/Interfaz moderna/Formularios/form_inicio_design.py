import tkinter as tk
from PIL import Image, ImageTk

class FormularioInicioDesign():

    def __init__(self, panel_principal):
              
        # Crear el Canvas
        self.canvas = tk.Canvas(panel_principal, width=400, height=300)
        self.canvas.pack()

        # Cargar la imagen
        self.image = Image.open("./Imagenes/logo.png")  
        self.photo = ImageTk.PhotoImage(self.image)

        # Mostrar la imagen en el Canvas
        self.canvas.create_image(200, 150, image=self.photo)