from re import X
from tkinter import ttk
import tkinter as tk
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import serial
import threading


class FormularioGraficasDesign():
    #Funciones necesarias
    variable_booleana = True #declaramos la variable booleana como global dentro de la clase

    def __init__(self, panel_principal):
        try:
            #global ser
            #self.ser = serial.Serial('/dev/ttyACM1',9600) #puerto serie
            self.ser = serial.Serial('COM13',9600) #puerto serie en pc
        except:
            print("No se pudo conectar el puerto serie")
        
        def update(data,new_data):
            old_data = max(0,len(data)-len(new_data)) 
            data_update = np.concatenate((data[-old_data:],new_data)) #concatena el valor o los valores agregados a new data
            return data_update
        
        # def on_tab_change(event):
        #     FormularioGraficasDesign.variable_booleana = not FormularioGraficasDesign.variable_booleana
        #     print("Evento de cambio de pestaña detectado.")
        #     print("Variable booleana ahora es:", FormularioGraficasDesign.variable_booleana)


        # def grafica_corriente(data):
        #     global diego
        #     diego = data
        #     while True:
        #         print("Holiwis")
        #         for i in range(2):
        #             new_data = self.ser.readline().decode().strip() #lee el valor de arduino
        #             if new_data.startswith("C:"): #diferencia si esta leyendo tensión o corriente
        #                 new_data= [float(new_data.split(":")[1])]
        #         # Update the plot with the new data  
        #                 data = update(data,new_data)  #meterle data viejo y el nuevo
        #                 line.set_ydata(data)
        #                 fig.canvas.draw() #dibuja
        #                 fig.canvas.flush_events() #actualiza contenido de la grafica

        def grafica_tension(data,data2):
            global diego
            diego = data2
            while True:
                for i in range(2):
                    new_data2 = self.ser.readline().decode().strip() #lee el valor de arduino
                    if new_data2.startswith("V:"): #diferencia si esta leyendo tensión o corriente
                        new_data2= [float(new_data2.split(":")[1])]
                # Update the plot with the new data  
                        data2 = update(data2,new_data2)  #meterle data viejo y el nuevo
                        line2.set_ydata(data2)
                        fig2.canvas.draw() #dibuja
                        fig2.canvas.flush_events() #actualiza contenido de la grafica
                    elif new_data2.startswith("C:"):
                        new_data2= [float(new_data2.split(":")[1])]
                # Update the plot with the new data  
                        data = update(data,new_data2)  #meterle data viejo y el nuevo
                        line.set_ydata(data)
                        fig.canvas.draw() #dibuja
                        fig.canvas.flush_events() #actualiza contenido de la grafica

        # Función para exportar datos a CSV
        def exportar_a_csv():
            # Crear un DataFrame con los datos de la gráfica
            coordenadas_x = np.linspace(0, 99,100)  # Generar linspace para coordenadas x
            # Crear un DataFrame de pandas con los arreglos
            data = pd.DataFrame({'Tiempo [s]': coordenadas_x, 'Tensión [V]': diego})
            # Nombre del archivo CSV
            nombre_archivo = "datos_pandas.csv"
            # Guardar el DataFrame en un archivo CSV
            data.to_csv(nombre_archivo, index=False)


        self.tabControl = ttk.Notebook(panel_principal) 
        
        self.tab1 = ttk.Frame(self.tabControl) 
        self.tab2 = ttk.Frame(self.tabControl) 
        
        self.tabControl.add(self.tab1, text ='Tensión') 
        self.tabControl.add(self.tab2, text ='Corriente') 
        self.tabControl.pack(expand = 1, fill ="both") 
        
        fig = plt.figure(figsize=(5,4), dpi=100)
        ax = fig.add_subplot(1,1,1)
        plt.ylim([0,3])
        plt.xlim([0,100]) 
         #graficar el tab 2
         #graficar en el tab 1
        fig2 = plt.figure(figsize=(5,4), dpi=100)
        ax2 = fig2.add_subplot(1,1,1)
        plt.ylim([0,35])
        plt.xlim([0,100]) 
        self.iv_curve = FigureCanvasTkAgg(fig2, master = self.tab1)
        self.iv_curve.draw() 
        self.iv_curve.get_tk_widget().pack() 

        self.iv_curve2 = FigureCanvasTkAgg(fig, master = self.tab2)
        self.iv_curve2.draw() 
        self.iv_curve2.get_tk_widget().pack() 
        data = [0]*100
        data2 = [0]*100
        line, = ax.plot(data)# declarar un objeto que se llama linea que es opropio de la libreria matplolib, osea poner la linea en el plot
        line2, = ax2.plot(data2)
        ax.set_xlabel('Tiempo (s)')
        ax.set_ylabel("Corriente")
        ax.set_title("Datos en tiempo real")
        ax.legend(['Corriente'],loc="upper right")

        ax2.set_xlabel('Tiempo (s)')
        ax2.set_ylabel("Tensión")
        ax2.set_title("Datos en tiempo real")
        ax2.legend(['Tensión'],loc="upper right")
        boton_exportar = tk.Button(panel_principal, text="Exportar a CSV", command=exportar_a_csv)
        boton_exportar.pack()
        thread2 = threading.Thread(target=grafica_tension(data,data2))
        thread2.start()


        
        
    