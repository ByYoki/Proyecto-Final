from pickle import FALSE
import tkinter as tk
from tkinter import PhotoImage, font
from PIL import ImageTk, Image
from numpy import False_
from Formularios.form_inicio_design import FormularioInicioDesign
from Formularios.form_intensidad_design import FormularioIntensidadDesign
from Formularios.form_grafica_design import FormularioGraficasDesign
import Formularios.variables_compartidas
from config import COLOR_BARRA_SUPERIOR, COLOR_MENU_LATERAL, COLOR_CUERPO_PRINCIPAL, COLOR_MENU_CURSOR_ENCIMA
import util.util_ventanas as util_vent
import util.util_imagenes as util_img


# se crea una clase porque se va ausar la programación orientada a objetos para crear la ventana
""""
lo que esta dento del parentesis es lo que hereda la clase
es decir en este caso la clase hereda todo lo de tkinter
"""
class FormularioMaestroDesign(tk.Tk): 
    def __init__(self): #las funciones en la clases son metodos Y LA PALABRA SELF SIEMPRE VA
        super().__init__()
        self.logo = util_img.leer_imagen("./Imagenes/logo.png", (560, 136))
        self.perfil = util_img.leer_imagen("./Imagenes/home.png", (100, 100)) #para que tkinter te lea la imagen de sebe cargar primero, por eso se coloca en el init
        #invocar cada diseño que le hagamos 
        self.config_window()
        self.paneles()
        self.controles_barra_superior()
        self.controles_menu_lateral()
        self.controles_cuerpo()
        self.protocol("WM_DELETE_WINDOW", self.on_closing)

    def config_window(self):
        #configuración inicial de la ventana
        self.title("Panel Solar")
        #self.iconbitmap("./Imagenes/panel_solar.ico")
        w, h = 1024,600
        util_vent.centrar_ventana(self,w,h)
        self.minsize(1024,600)
        

    def paneles(self):
        # crear paneles: barra superior, lateral y cuerpo principal
        self.barra_superior = tk.Frame(
            self, bg= COLOR_BARRA_SUPERIOR, height= 50
        ) 
        self.barra_superior.pack(side=tk.TOP,fill="both") #indicar la forma como se va a guardar

        self.menu_lateral = tk.Frame(
            self, bg= COLOR_MENU_LATERAL, width = 150
        ) 
        self.menu_lateral.pack(side=tk.LEFT,fill="both", expand=False)

        self.cuerpo_principal = tk.Frame(
            self, bg= COLOR_CUERPO_PRINCIPAL, width = 150
        ) 
        self.cuerpo_principal.pack(side=tk.RIGHT,fill="both", expand=True)

    def controles_barra_superior(self):
        #cpnfiguración de la barra superior 
        font_awesome = font.Font(family="FontAwesome", size=12) # para los iconos
        
        #etiqueta de titulo 
        self.labelTitulo = tk.Label(self.barra_superior, text="Prototipo Emulador Fotovoltaico") #self.barra para que se guarde en el panel y no enla ventana
        self.labelTitulo.config(fg="#fff", font=(
            "Roboto",15),bg=COLOR_BARRA_SUPERIOR,pady=10,width=27)
        self.labelTitulo.pack(side=tk.LEFT)

        #boton del menu lateral
        self.buttonMenuLateral = tk.Button(self.barra_superior, text="\uf0c9",font=font_awesome,
                                           command=self.toggle_panel, bd = 0, bg=COLOR_BARRA_SUPERIOR, fg = "white")
        self.buttonMenuLateral.pack(side=tk.LEFT) # el text con  ese codgio raro es un codgio de iconos

        #etiqueta de informacion
        self.labelTitulo = tk.Label(
            self.barra_superior, text="aamoya@uninorte.edu.co \n barriossd@uninorte.edu.co")
        self.labelTitulo.config(fg="#fff",font=(
            "Roboto",10), bg=COLOR_BARRA_SUPERIOR, padx=10, width=20)
        self.labelTitulo.pack(side=tk.RIGHT)

    def controles_menu_lateral(self):
        # configuración del menu lateral
        ancho_menu = 20
        alto_menu = 2
        font_awesome = font.Font(family="FontAwesome", size=15) #para los iconos

        #etiqueta del perfil
        self.labelPerfil = tk.Label(
            self.menu_lateral, image =self.perfil, bg=COLOR_MENU_LATERAL)
        self.labelPerfil.pack(side=tk.TOP,pady=30)

        #botones del menú lateral
        """
        ya que lo botones tendran la misma configruacion se crea una lista 
        para colocarle los mismos atributos y enun for se recorre todo
        """
        self.buttonDashBoard = tk.Button(self.menu_lateral,)
        self.buttonLuminarias = tk.Button(self.menu_lateral)
        self.buttonGraficas = tk.Button(self.menu_lateral)
        self.buttonDInfo = tk.Button(self.menu_lateral)

        buttons_info = [
            ("Inicio","\uf109",self.buttonDashBoard,self.abrir_panel_inicio),
            ("Luminarias","\uf007",self.buttonLuminarias,self.abrir_panel_intensidad),
            ("Gráficas","\uf03e",self.buttonGraficas,self.abrir_panel_graficas),
            ("Info","\uf013",self.buttonDInfo,self.abrir_panel_graficas)
        ]

        for text, icon, button, comando in buttons_info:
            self.configurar_boton_menu(button,text,icon, font_awesome,ancho_menu,alto_menu,comando)
       
    def controles_cuerpo(self):
        #imagen de cuerpo principal
        label =tk.Label(self.cuerpo_principal,image=self.logo,
                        bg=COLOR_CUERPO_PRINCIPAL)
        label.place(x=0, y=0, relheight=1, relwidth=1)

    def configurar_boton_menu(self,button,text,icon,font_awesome,ancho_menu,alto_menu, comando):
        button.config(text= f"{icon} {text}", anchor="w", font=font_awesome,
                      bd=0,bg=COLOR_MENU_LATERAL,fg="white", width=ancho_menu,height =alto_menu, command= comando)
        button.pack(side=tk.TOP) # se vana cumuland
        self.bind_hover_events(button) # se genera un evento cuando se dectecta el mouse sobre ellos

    def bind_hover_events(self,button):
        #asociar eventos enter y leave con la funcion
        # el bind es una propiedad que vienen con todos los metodos de widget y se indica como se activa
        button.bind("<Enter>",lambda event:self.on_enter(event, button))
        button.bind("<Leave>",lambda event:self.on_leave(event, button))

    def on_enter(self,event, button):
        #cambiar esilo al pasar ratoón encima
        button.config(bg=COLOR_MENU_CURSOR_ENCIMA, fg="white")

    def on_leave(self,event, button):
        #cambiar esilo al quitar el raton de encima
        button.config(bg=COLOR_MENU_LATERAL, fg="white")

    def toggle_panel(self):
        # Alternatr la visibilidad del menú lateral
        if self.menu_lateral.winfo_ismapped(): #si esta visible
            self.menu_lateral.pack_forget() # quitalo, retiralo
        else:
            self.menu_lateral.pack(side=tk.LEFT,fill="y")

    def abrir_panel_intensidad(self):
        self.limpiar_panel(self.cuerpo_principal)
        FormularioIntensidadDesign(self.cuerpo_principal)

    def abrir_panel_graficas(self):
        self.limpiar_panel(self.cuerpo_principal)
        FormularioGraficasDesign(self.cuerpo_principal)

    def abrir_panel_inicio(self):
        self.limpiar_panel(self.cuerpo_principal)
        # # Load the image file
        # image = Image.open("./Imagenes/logo.png")  

        # # Convert the image to a Tkinter-compatible object
        # tk_image = ImageTk.PhotoImage(image)

        # # Create a label with the image
        # label = tk.Label(self.cuerpo_principal, image=tk_image)
        # label.pack()
        FormularioInicioDesign(self.cuerpo_principal)
        
        
    def limpiar_panel(self,panel):
        for widget in panel.winfo_children():
            widget.destroy()
    
    def guardar_estado(self):
        # Variables adicionales que deseas guardar
        variables = {
            "modulos": Formularios.variables_compartidas.modulos,
            "sliders": Formularios.variables_compartidas.sliders,
            "verificador": Formularios.variables_compartidas.verificador
            # Agrega más variables aquí según sea necesario
        }

        # Guardar el estado en el archivo
        with open('./Formularios/variables_compartidas.py', 'w') as file:
            for key, value in variables.items():
                file.write(f"{key} = {value}\n") 

    def on_closing(self):
        Formularios.variables_compartidas.modulos["state_mod1"] = False
        Formularios.variables_compartidas.modulos["state_mod2"] = False
        Formularios.variables_compartidas.modulos["state_mod3"] = False
        Formularios.variables_compartidas.modulos["state_mod4"] = False
        Formularios.variables_compartidas.modulos["state_mod5"] = False
        Formularios.variables_compartidas.modulos["state_mod6"] = False

        Formularios.variables_compartidas.sliders["slider1_val"] = '100\n'
        Formularios.variables_compartidas.sliders["slider2_val"] = '100\n'
        Formularios.variables_compartidas.sliders["slider3_val"] = '100\n'
        Formularios.variables_compartidas.sliders["slider4_val"] = '100\n'
        Formularios.variables_compartidas.sliders["slider5_val"] = '100\n'
        Formularios.variables_compartidas.sliders["slider6_val"] = '100\n'

        Formularios.variables_compartidas.verificador["1"] = 0
        Formularios.variables_compartidas.verificador["2"] = 0
        Formularios.variables_compartidas.verificador["3"] = 0
        Formularios.variables_compartidas.verificador["4"] = 0
        Formularios.variables_compartidas.verificador["5"] = 0
        Formularios.variables_compartidas.verificador["6"] = 0
        
        self.guardar_estado()
        self.destroy()


