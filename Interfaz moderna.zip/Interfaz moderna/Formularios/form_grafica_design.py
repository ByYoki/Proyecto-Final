from re import X
from tkinter import ttk
import tkinter as tk
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import figure
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class FormularioGraficasDesign():
    #Funciones necesarias

    def __init__(self, panel_principal):

        def lista_aleatoria(n,minimo,maximo):
                    lista = []
                    for i in range(n):
                        numero = np.random.randint(minimo,maximo)
                        lista.append(numero)
                    return lista 
        
        def update(data,new_data):
            old_data = max(0,len(data)-len(new_data)) 
            data_update = np.concatenate((data[-old_data:],new_data)) #concatena el valor o los valores agregados a new data
            return data_update
                      
        def grafica(data, data2):
            global diego, dio
            diego = data
            dio = data2
            while True:
                new_data = lista_aleatoria(1,0,100) #crea nuevos valores
                nnew_data = lista_aleatoria(1,0,100) #crea nuevos valores
                # Update the plot with the new data  
                diego = update(diego, new_data)  #meterle data viejo y al nuevo
                dio = update(dio, nnew_data)
                line.set_ydata(diego)
                line.set_xdata(dio)
                fig.canvas.draw() #dibuja
                fig.canvas.flush_events() #actualiza contenido de la grafica

        # Función para exportar datos a CSV
        def exportar_a_csv():
            # Crear un DataFrame con los datos de la gráfica
            coordenadas_x = np.linspace(0, 99,100)  # Generar linspace para coordenadas x
            # Crear un DataFrame de pandas con los arreglos
            data = pd.DataFrame({'Tiempo [s]': coordenadas_x, 'Tensión [V]': diego})

            # Nombre del archivo CSV
            nombre_archivo = "datos_pandas.csv"

            # Guardar el DataFrame en un archivo CSV
            data.to_csv(nombre_archivo, index=False)
            # df = pd.DataFrame({'Tiempo': coordenadas_x, 'Valor': [diego[x] for x in coordenadas_x]})
            # df.to_csv('datos.csv', index=False)  # Exportar DataFrame a CSV sin índice

        # figura = Figure(figsize=(8,6),dpi=100)
        # ax1 = figura.add_subplot(211)
        # ax2 = figura.add_subplot(212)

        # figura.subplots_adjust(hspace=0.4)
        # self.grafico1(ax1)

        # canvas = FigureCanvasTkAgg(figura,master=panel_principal)
        # canvas.draw()
        # canvas.get_tk_widget().pack(side=tk.TOP,fill=tk.BOTH,expand=1)

        self.tabControl = ttk.Notebook(panel_principal) 
        
        self.tab1 = ttk.Frame(self.tabControl) 
        self.tab2 = ttk.Frame(self.tabControl) 
        
        self.tabControl.add(self.tab1, text ='Tab 1') 
        self.tabControl.add(self.tab2, text ='Tab 2') 
        self.tabControl.pack(expand = 1, fill ="both") 
        
        fig = plt.figure(figsize=(5,4), dpi=100)
        ax = fig.add_subplot(1,1,1)
        plt.ylim([0,100])
        plt.xlim([0,100]) 

        self.iv_curve = FigureCanvasTkAgg(fig, master = self.tab2)
        self.iv_curve.draw() 
        self.iv_curve.get_tk_widget().pack() 
        #data = [0]*100 #crea una lista de cien ceros
        data = lista_aleatoria(100,0,100)
        data2 = lista_aleatoria(100,0,100)
        line, = ax.plot(data) # declarar un objeto que se llama linea que es opropio de la libreria matplolib, osea poner la linea en el plot
        ax.set_xlabel('Tiempo (s)')
        ax.set_ylabel("Tensión")
        ax.set_title("Datos en tiempo real")
        ax.legend(['Tensión'],loc="upper right")
        boton_exportar = tk.Button(panel_principal, text="Exportar a CSV", command=exportar_a_csv)
        boton_exportar.pack()
        grafica(data,data2)

        # canvas = FigureCanvasTkAgg(fig, master = self.tab2)
        # canvas.draw() 
        # canvas.get_tk_widget().pack() 
        # #data = [0]*100 #crea una lista de cien ceros
        # data = lista_aleatoria(100,0,100)
        # data2 = lista_aleatoria(100,0,100)
        # line, = ax.plot(data) # declarar un objeto que se llama linea que es opropio de la libreria matplolib, osea poner la linea en el plot
        # ax.set_xlabel('Tiempo (s)')
        # ax.set_ylabel("Tensión")
        # ax.set_title("Datos en tiempo real")
        # ax.legend(['Tensión'],loc="upper right")
        # boton_exportar = tk.Button(panel_principal, text="Exportar a CSV", command=exportar_a_csv)
        # boton_exportar.pack()
        # grafica(data,data2)

        
    