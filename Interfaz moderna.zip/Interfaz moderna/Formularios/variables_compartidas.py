modulos = {'state_mod1': True, 'state_mod2': False, 'state_mod3': False, 'state_mod4': True, 'state_mod5': False, 'state_mod6': True}
sliders = {'slider1_val': '30.799999999999997\n', 'slider2_val': '0\n', 'slider3_val': '100', 'slider4_val': '100\n', 'slider5_val': '0\n', 'slider6_val': '100\n'}
verificador = {'1': 1, '2': 0, '3': 0, '4': 1, '5': 0, '6': 1}
