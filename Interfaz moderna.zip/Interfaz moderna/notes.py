from pathlib import Path

from tkinter import *
# Explicit imports to satisfy Flake8
#import RPi.GPIO as GPIO
from gpiozero import LED,PWMLED
#funciones de apagr y prender
led=PWMLED(18)
ledB=PWMLED(6)
ledC=PWMLED(12)
def intensidadA(event):
    event=slider1.get()
    led.value=event*0.01

def intensidadB(event):
    event=slider2.get()
    ledB.value=event*0.01    

def intensidadC(event):
    event=slider3.get()
    ledC.value=event*0.01

def apagar():
    button_1["state"]=NORMAL #habilita boton encender
    button_2["state"]=DISABLED # desabilita el boton apagar
    slider1.set(0)
    intensidadA
    slider1["state"]=DISABLED #desabilita slider

def apagarB():
    button_ledB_on["state"]=NORMAL #habilita boton encender
    button_ledB_off["state"]=DISABLED # desabilita el boton apagar
    slider2.set(0)
    intensidadB
    slider2["state"]=DISABLED #desabilita slider

def apagarC():
    button_ledC_on["state"]=NORMAL #habilita boton encender
    button_ledC_off["state"]=DISABLED # desabilita el boton apagar
    slider3.set(0)
    intensidadC
    slider3["state"]=DISABLED #desabilita slider


def encender(): 
    button_2["state"]=NORMAL #habiliad boton apagar
    button_1["state"]=DISABLED #desabilita boton apagar
    slider1["state"]=NORMAL # habilita slider
    slider1.set(100)
    intensidadA

def encenderB(): 
    button_ledB_off["state"]=NORMAL #habiliad boton apagar
    button_ledB_on["state"]=DISABLED #desabilita boton apagar
    slider2["state"]=NORMAL # habilita slider
    slider2.set(100)
    intensidadB

def encenderC(): 
    button_ledC_off["state"]=NORMAL #habiliad boton apagar
    button_ledC_on["state"]=DISABLED #desabilita boton apagar
    slider3["state"]=NORMAL # habilita slider
    slider3.set(100)
    intensidadC
    
#GUI
OUTPUT_PATH = Path(_file_).parent
ASSETS_PATH = OUTPUT_PATH / Path(r"/home/pi/Descargas/build/assets/frame0")


def relative_to_assets(path: str) -> Path:
    return ASSETS_PATH / Path(path)


window = Tk()

window.geometry("800x500")
window.configure(bg = "#FFFFFF")


canvas = Canvas(
    window,
    bg = "#FFFFFF",
    height = 500,
    width = 800,
    bd = 0,
    highlightthickness = 0,
    relief = "ridge"
)

canvas.place(x = 0, y = 0)
canvas.create_rectangle(
    0.0,
    2.842170943040401e-14,
    800.0,
    50.00000000000003,
    fill="#2645B0",
    outline="")

canvas.create_text(
    27.999999999999943,
    10.999999999999972,
    anchor="nw",
    text="Leds usando Tkinter",
    fill="#FFFFFF",
    font=("MontserratRoman Regular", 32 * -1)
)

# botones de encender
button_image_1 = PhotoImage(
    file=relative_to_assets("button_1.png"))
button_1 = Button(
    image=button_image_1,
    borderwidth=0,
    highlightthickness=0,
    command=encender,
    relief="flat"
)
button_1.place(
    x=17.999999999999943,
    y=175.99999999999997,
    width=122.0,
    height=29.0
)

# led B

button_ledB_on = Button(
    image=button_image_1,
    borderwidth=0,
    highlightthickness=0,
    command=encenderB,
    relief="flat"
)
button_ledB_on.place(
    x=17.999999999999943,
    y=341,
    width=122.0,
    height=29.0
)

#led C
button_ledC_on = Button(
    image=button_image_1,
    borderwidth=0,
    highlightthickness=0,
    command=encenderC,
    relief="flat"
)
button_ledC_on.place(
    x=382,
    y=341,
    width=122.0,
    height=29.0
)

button_image_2 = PhotoImage(
    file=relative_to_assets("button_2.png"))

#botones de apagar
button_2 = Button(
    image=button_image_2,
    borderwidth=0,
    highlightthickness=0,
    command=apagar,
    relief="flat",
)
button_2.place(
    x=172.99999999999994,
    y=175.99999999999997,
    width=122.0,
    height=29.0
)

button_ledB_off = Button(
    image=button_image_2,
    borderwidth=0,
    highlightthickness=0,
    command=apagarB,
    relief="flat",
)
button_ledB_off.place(
    x=172.99999999999994,
    y=341,
    width=122.0,
    height=29.0
)

button_ledC_off = Button(
    image=button_image_2,
    borderwidth=0,
    highlightthickness=0,
    command=apagarC,
    relief="flat",
)
button_ledC_off.place(
    x=537,
    y=341,
    width=122.0,
    height=29.0
)

button_2["state"]=DISABLED
button_ledB_off["state"]=DISABLED
button_ledC_off["state"]=DISABLED

#slider led 1
slider1 = Scale(window, from_=0,to=100, orient=HORIZONTAL,relief=FLAT,
                widt=5,length=260,background="#22A6F2",command=intensidadA)
slider1.place(x=21 , y=220)

# slider led 2
slider2 = Scale(window, from_=0,to=100, orient=HORIZONTAL,relief=FLAT,
                widt=5,length=260,background="#22A6F2")
slider2.place(x=21 , y=375)

# slider led 3
slider3 = Scale(window, from_=0,to=100, orient=HORIZONTAL,relief=FLAT,
                widt=5,length=260,background="#22A6F2")
slider3.place(x=390 , y=375)

slider1["state"]=DISABLED #desabilitar cuando carga
slider2["state"]=DISABLED #desabilitar cuando carga
slider3["state"]=DISABLED #desabilitar cuando carga

canvas.create_text(
    106.99999999999994,
    68.99999999999997,
    anchor="nw",
    text="LED 1",
    fill="#000000",
    font=("MontserratRoman Regular", 32 * -1)
)

image_image_1 = PhotoImage(
    file=relative_to_assets("image_1.png"))
image_1 = canvas.create_image(
    642.0,
    131.99999999999997,
    image=image_image_1
)

image_image_2 = PhotoImage(
    file=relative_to_assets("image_2.png"))
image_2 = canvas.create_image(
    149.99999999999994,
    138.99999999999997,
    image=image_image_2
)

image_3 = canvas.create_image(
    149,
    310,
    image=image_image_2
)

image_4 = canvas.create_image(
    525,
    310,
    image=image_image_2
)

window.resizable(False, False)
window.mainloop()