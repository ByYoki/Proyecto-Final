from Formularios.form_main_designer import FormularioMaestroDesign

app = FormularioMaestroDesign() # instanciacion del objeto 
app.mainloop()