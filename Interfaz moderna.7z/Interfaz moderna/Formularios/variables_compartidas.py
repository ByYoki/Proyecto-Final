modulos = {'state_mod1': False, 'state_mod2': False, 'state_mod3': False, 'state_mod4': False, 'state_mod5': False, 'state_mod6': False}
sliders = {'slider1_val': '100\n', 'slider2_val': '100\n', 'slider3_val': '100\n', 'slider4_val': '100\n', 'slider5_val': '100\n', 'slider6_val': '100\n'}
verificador = {'1': 0, '2': 0, '3': 0, '4': 0, '5': 0, '6': 0}
