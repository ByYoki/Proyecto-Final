from PIL import ImageTk, Image #instalar imagenes .png

def leer_imagen (path, size):
        return ImageTk.PhotoImage(Image.open(path).resize(size, Image.ADAPTIVE))
