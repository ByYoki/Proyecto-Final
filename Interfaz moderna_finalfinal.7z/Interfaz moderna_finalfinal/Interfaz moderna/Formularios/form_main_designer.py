from pickle import FALSE
import tkinter as tk
from tkinter import ttk
from tkinter import PhotoImage, font
from PIL import ImageTk, Image
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
# from Formularios.form_inicio_design import FormularioInicioDesign
# from Formularios.form_intensidad_design import FormularioIntensidadDesign
# from Formularios.form_grafica_design import FormularioGraficasDesign
import Formularios.variables_compartidas
from config import COLOR_BARRA_SUPERIOR, COLOR_MENU_LATERAL, COLOR_CUERPO_PRINCIPAL, COLOR_MENU_CURSOR_ENCIMA
import util.util_ventanas as util_vent
import util.util_imagenes as util_img
import threading
import serial
import time


# se crea una clase porque se va ausar la programación orientada a objetos para crear la ventana
""""
lo que está dento del parentesis es lo que hereda la clase
es decir en este caso la clase hereda todo lo de tkinter
"""

try:
    ser = serial.Serial('/dev/ttyACM0',9600) #puerto serie en pc
except:
    print("No se pudo conectar el puerto serie")

class FormularioMaestroDesign(tk.Tk): 
    def __init__(self): #las funciones en la clases son metodos Y LA PALABRA SELF SIEMPRE VA
        super().__init__()
        self.logo = util_img.leer_imagen("./Imagenes/monta.jpeg", (560, 560))
        self.info_imag = util_img.leer_imagen("./Imagenes/info.png", (747, 484))
        self.perfil = util_img.leer_imagen("./Imagenes/home.png", (100, 100)) #para que tkinter te lea la imagen de sebe cargar primero, por eso se coloca en el init
        #invocar cada diseño que le hagamos 
        self.config_window()
        self.paneles()
        self.controles_barra_superior()
        self.controles_menu_lateral()
        self.controles_cuerpo()
        self.protocol("WM_DELETE_WINDOW", self.on_closing)

    def config_window(self):
        #configuración inicial de la ventana
        self.title("PEF 2.0")
        #self.iconbitmap("./Imagenes/panel_solar.ico")
        w, h = 1366,720
        util_vent.centrar_ventana(self,w,h)
        # self.minsize(1024,600)
        self.minsize(1366,720)
        # self.attributes('-fullscreen', True)
        

    def paneles(self):
        # crear paneles: barra superior, lateral y cuerpo principal
        self.barra_superior = tk.Frame(
            self, bg= COLOR_BARRA_SUPERIOR, height= 50
        ) 
        self.barra_superior.pack(side=tk.TOP,fill="both") #indicar la forma como se va a guardar

        self.menu_lateral = tk.Frame(
            self, bg= COLOR_MENU_LATERAL, width = 150
        ) 
        self.menu_lateral.pack(side=tk.LEFT,fill="both", expand=False)

        self.cuerpo_principal = tk.Frame(
            self, bg= COLOR_CUERPO_PRINCIPAL, width = 150
        ) 
        self.cuerpo_principal.pack(side=tk.RIGHT,fill="both", expand=True)

    def controles_barra_superior(self):
        #cpnfiguración de la barra superior 
        font_awesome = font.Font(family="FontAwesome", size=12) # para los iconos
        
        #etiqueta de titulo 
        self.labelTitulo = tk.Label(self.barra_superior, text="Prototipo Emulador Fotovoltaico") #self.barra para que se guarde en el panel y no enla ventana
        self.labelTitulo.config(fg="#fff", font=(
            "Roboto",15),bg=COLOR_BARRA_SUPERIOR,pady=10,width=27)
        self.labelTitulo.pack(side=tk.LEFT)

        #boton del menu lateral
        self.buttonMenuLateral = tk.Button(self.barra_superior, text="\uf0c9",font=font_awesome,
                                           command=self.toggle_panel, bd = 0, bg=COLOR_BARRA_SUPERIOR, fg = "white")
        self.buttonMenuLateral.pack(side=tk.LEFT) # el text con  ese codgio raro es un codgio de iconos

        #etiqueta de informacion
        self.labelTitulo = tk.Label(
            self.barra_superior, text="aamoya@uninorte.edu.co \n barriossd@uninorte.edu.co")
        self.labelTitulo.config(fg="#fff",font=(
            "Roboto",10), bg=COLOR_BARRA_SUPERIOR, padx=10, width=20)
        self.labelTitulo.pack(side=tk.RIGHT)

    def controles_menu_lateral(self):
        # configuración del menu lateral
        ancho_menu = 20
        alto_menu = 2
        font_awesome = font.Font(family="FontAwesome", size=15) #para los iconos

        #etiqueta del perfil
        self.labelPerfil = tk.Label(
            self.menu_lateral, image =self.perfil, bg=COLOR_MENU_LATERAL)
        self.labelPerfil.pack(side=tk.TOP,pady=30)

        #botones del menú lateral
        """
        ya que lo botones tendran la misma configruacion se crea una lista 
        para colocarle los mismos atributos y enun for se recorre todo
        """
        self.buttonDashBoard = tk.Button(self.menu_lateral,)
        self.buttonLuminarias = tk.Button(self.menu_lateral)
        self.buttonGraficas = tk.Button(self.menu_lateral)
        self.buttonDInfo = tk.Button(self.menu_lateral)

        buttons_info = [
            ("Inicio","\uf109",self.buttonDashBoard,self.controles_cuerpo),
            ("Luminarias","\uf007",self.buttonLuminarias,self.abrir_panel_intensidad),
            ("Gráficas","\uf03e",self.buttonGraficas,self.abrir_panel_graficas),
            ("Info","\uf013",self.buttonDInfo,self.abrir_panel_info)
        ]

        for text, icon, button, comando in buttons_info:
            self.configurar_boton_menu(button,text,icon, font_awesome,ancho_menu,alto_menu,comando)
       
    def controles_cuerpo(self):
        #imagen de cuerpo principal
        label =tk.Label(self.cuerpo_principal,image=self.logo,
                        bg=COLOR_CUERPO_PRINCIPAL)
        label.place(x=0, y=0, relheight=1, relwidth=1)

    def abrir_panel_info(self):
        #imagen de cuerpo principal
        label =tk.Label(self.cuerpo_principal,image=self.info_imag,
                        bg=COLOR_CUERPO_PRINCIPAL)
        label.place(x=0, y=0, relheight=1, relwidth=1)

    def configurar_boton_menu(self,button,text,icon,font_awesome,ancho_menu,alto_menu, comando):
        button.config(text= f"{icon} {text}", anchor="w", font=font_awesome,
                      bd=0,bg=COLOR_MENU_LATERAL,fg="white", width=ancho_menu,height =alto_menu, command= comando)
        button.pack(side=tk.TOP) # se vana cumuland
        self.bind_hover_events(button) # se genera un evento cuando se dectecta el mouse sobre ellos

    def bind_hover_events(self,button):
        #asociar eventos enter y leave con la funcion
        # el bind es una propiedad que vienen con todos los metodos de widget y se indica como se activa
        button.bind("<Enter>",lambda event:self.on_enter(event, button))
        button.bind("<Leave>",lambda event:self.on_leave(event, button))

    def on_enter(self,event, button):
        #cambiar esilo al pasar ratoón encima
        button.config(bg=COLOR_MENU_CURSOR_ENCIMA, fg="white")

    def on_leave(self,event, button):
        #cambiar esilo al quitar el raton de encima
        button.config(bg=COLOR_MENU_LATERAL, fg="white")

    def toggle_panel(self):
        # Alternatr la visibilidad del menú lateral
        if self.menu_lateral.winfo_ismapped(): #si esta visible
            self.menu_lateral.pack_forget() # quitalo, retiralo
        else:
            self.menu_lateral.pack(side=tk.LEFT,fill="y")

    def abrir_panel_intensidad(self):
        self.limpiar_panel(self.cuerpo_principal)
        FormularioIntensidadDesign(self.cuerpo_principal)

    def abrir_panel_graficas(self):
        self.limpiar_panel(self.cuerpo_principal)
        FormularioGraficasDesign(self.cuerpo_principal)
        
        
    def limpiar_panel(self,panel):
        for widget in panel.winfo_children():
            widget.destroy()
    
    def guardar_estado(self):
        # Variables adicionales que deseas guardar
        variables = {
            "modulos": Formularios.variables_compartidas.modulos,
            "sliders": Formularios.variables_compartidas.sliders,
            "verificador": Formularios.variables_compartidas.verificador
            # Agrega más variables aquí según sea necesario
        }

        # Guardar el estado en el archivo
        with open('./Formularios/variables_compartidas.py', 'w') as file:
            for key, value in variables.items():
                file.write(f"{key} = {value}\n") 

    def on_closing(self):
        Formularios.variables_compartidas.modulos["state_mod1"] = False
        Formularios.variables_compartidas.modulos["state_mod2"] = False
        Formularios.variables_compartidas.modulos["state_mod3"] = False
        Formularios.variables_compartidas.modulos["state_mod4"] = False
        Formularios.variables_compartidas.modulos["state_mod5"] = False
        Formularios.variables_compartidas.modulos["state_mod6"] = False
        # Formularios.variables_compartidas.modulos["state_modg"] = False

        Formularios.variables_compartidas.sliders["slider1_val"] = '100\n'
        Formularios.variables_compartidas.sliders["slider2_val"] = '100\n'
        Formularios.variables_compartidas.sliders["slider3_val"] = '100\n'
        Formularios.variables_compartidas.sliders["slider4_val"] = '100\n'
        Formularios.variables_compartidas.sliders["slider5_val"] = '100\n'
        Formularios.variables_compartidas.sliders["slider6_val"] = '100\n'
        # Formularios.variables_compartidas.sliders["sliderg_val"] = '100\n'

        Formularios.variables_compartidas.verificador["1"] = 0
        Formularios.variables_compartidas.verificador["2"] = 0
        Formularios.variables_compartidas.verificador["3"] = 0
        Formularios.variables_compartidas.verificador["4"] = 0
        Formularios.variables_compartidas.verificador["5"] = 0
        Formularios.variables_compartidas.verificador["6"] = 0
        # Formularios.variables_compartidas.verificador["g"] = 0
        
        self.guardar_estado()
        self.destroy()


class FormularioIntensidadDesign():
    def __init__(self, panel_principal):

        # --------------- Esto era necesario solo para los LEDs ----------------
        # self.led = PWMLED(18)
        # self.ledB = PWMLED(6)
        # self.ledC = PWMLED(12)
        # self.ledD = PWMLED(17)
        # self.ledE = PWMLED(19)
        # self.ledF = PWMLED(20)
        # ----------------------------------------------------------------------
        # Cargar la imagen
        self.canvas1 = tk.Canvas(panel_principal, width=575, height=100, bg=COLOR_MENU_LATERAL)
        self.canvas1.place(x=50,y=230)

        self.canvas2 = tk.Canvas(panel_principal, width=575, height=280, bg=COLOR_MENU_LATERAL)
        self.canvas2.place(x=50,y=350)

        # ----------------------------------------------------------------------
        # def actualizar_valor(self, event = None):
        #     print("el valor es: ", self.slider1.get())

        # def actualizar_valor_final(self):
        #     event = self.slider1.get()
        #     event = str(event) + '\n'
        # #     # ser.write(event.encode())
        

        # 1. Cargar las imágenes del módulo
        self.image1 = Image.open("./Imagenes/modulo.png")  
        self.image2 = self.image1.resize((300, 200))  # Cambiar el tamaño a 300x200
        self.photo = ImageTk.PhotoImage(self.image2)

        ## Mostrar la imagen en el Canvas
        # self.canvas.create_image(self.image2.width/2, self.image2.height/2, image=self.photo)
        self.modulo = tk.Label(panel_principal, image=self.photo)
        self.modulo.place(x=185,y=25)
        # # self.canvas.create_image(20, 20, anchor=tk.CENTER, image=self.photo)

        ## Crear la imagen transparente como spaceholder para los módulos
        self.imagen_transparente = Image.new('RGBA', (1, 1), (0, 0, 0, 0))
        self.imagen_transparente_tk = ImageTk.PhotoImage(self.imagen_transparente)

        self.mod1 = Image.open("./Imagenes/mod1.png")
        self.mod1_rs = self.mod1.resize((66,59))
        self.mod1_imag = ImageTk.PhotoImage(self.mod1_rs)

        ### Mostrar las imágenes de los módulos en el widget Label
        self.modulo1 = tk.Label(panel_principal, image=self.imagen_transparente_tk)
        self.modulo1.place(x=0,y=0)
        
        self.mod2 = Image.open("./Imagenes/mod2.png")
        self.mod2_rs = self.mod2.resize((66,59))
        self.mod2_imag = ImageTk.PhotoImage(self.mod2_rs)

        self.modulo2 = tk.Label(panel_principal, image=self.imagen_transparente_tk)
        self.modulo2.place(x=0,y=0)

        self.mod3 = Image.open("./Imagenes/mod3.png")
        self.mod3_rs = self.mod3.resize((66,59))
        self.mod3_imag = ImageTk.PhotoImage(self.mod3_rs)

        self.modulo3 = tk.Label(panel_principal, image=self.imagen_transparente_tk)
        self.modulo3.place(x=0,y=0)

        self.mod4 = Image.open("./Imagenes/mod4.png")
        self.mod4_rs = self.mod4.resize((66,59))
        self.mod4_imag = ImageTk.PhotoImage(self.mod4_rs)

        self.modulo4= tk.Label(panel_principal, image=self.imagen_transparente_tk)
        self.modulo4.place(x=0,y=0)

        self.mod5 = Image.open("./Imagenes/mod5.png")
        self.mod5_rs = self.mod5.resize((66,59))
        self.mod5_imag = ImageTk.PhotoImage(self.mod5_rs)

        self.modulo5= tk.Label(panel_principal, image=self.imagen_transparente_tk)
        self.modulo5.place(x=0,y=0)

        self.mod6 = Image.open("./Imagenes/mod6.png")
        self.mod6_rs = self.mod6.resize((66,59))
        self.mod6_imag = ImageTk.PhotoImage(self.mod6_rs)

        self.modulo6= tk.Label(panel_principal, image=self.imagen_transparente_tk)
        self.modulo6.place(x=0,y=0)

        # ----------------------------------------------------------------------
        # ---------------------------- GUI Settings ----------------------------

        ## ----------------------------- Botones -------------------------------
        self.var = tk.IntVar()
        self.checkbox1 = tk.Checkbutton(master=panel_principal, text="Manejo grupal", variable=self.var, command = self.enable_module)
        self.checkbox1.place(
        x=50, 
        y=200
        )

        self.buttonEncenderG = tk.Button(master=panel_principal, text="Encender", activebackground="#84E184", command=lambda:[self.encenderG()])
        self.buttonEncenderG.place(
        x=70,
        y=250,
        width=130.0,
        height=30.0
        )
        
        self.buttonApagarG = tk.Button(master=panel_principal, text="Apagar", activebackground="#84E184", command=lambda:[self.apagarG()])
        self.buttonApagarG.place(
        x=200,
        y=250,
        width=130.0,
        height=30.0
        )
        

        self.buttonEncender1 = tk.Button(master=panel_principal, text="Encender", activebackground="#84E184", command=lambda:[self.encender()])
        self.buttonEncender1.place(
        x=70,
        y=370,
        width=130.0,
        height=30.0
        )
        
        self.buttonApagar1 = tk.Button(master=panel_principal, text="Apagar", activebackground="#E84B4F", command=lambda:[self.apagar()])
        self.buttonApagar1.place(
        x=200,
        y=370,
        width=130.0,
        height=30.0
        )

        self.buttonEncender2 = tk.Button(master=panel_principal, text="Encender", activebackground="#84E184", command=lambda:[self.encenderB()])
        self.buttonEncender2.place(
        x=350,
        y=370,
        width=130.0,
        height=30.0
        )
        
        self.buttonApagar2 = tk.Button(master=panel_principal, text="Apagar", activebackground="#E84B4F", command=self.apagarB)
        self.buttonApagar2.place(
        x=480,
        y=370,
        width=130.0,
        height=30.0
        )

        self.buttonEncender3 = tk.Button(master=panel_principal, text="Encender", activebackground="#84E184", command=self.encenderC)
        self.buttonEncender3.place(
        x=70,
        y=460,
        width=130.0,
        height=30.0
        )
        
        self.buttonApagar3 = tk.Button(master=panel_principal, text="Apagar", activebackground="#E84B4F", command=self.apagarC)
        self.buttonApagar3.place(
        x=200,
        y=460,
        width=130.0,
        height=30.0
        )

        self.buttonEncender4 = tk.Button(master=panel_principal, text="Encender", activebackground="#84E184", command=self.encenderD)
        self.buttonEncender4.place(
        x=350,
        y=460,
        width=130.0,
        height=30.0
        )
        
        self.buttonApagar4 = tk.Button(master=panel_principal, text="Apagar", activebackground="#E84B4F", command=self.apagarD)
        self.buttonApagar4.place(
        x=480,
        y=460,
        width=130.0,
        height=30.0
        )

        self.buttonEncender5 = tk.Button(master=panel_principal, text="Encender", activebackground="#84E184", command=self.encenderE)
        self.buttonEncender5.place(
        x=70,
        y=550,
        width=130.0,
        height=30.0
        )
        
        self.buttonApagar5 = tk.Button(master=panel_principal, text="Apagar", activebackground="#E84B4F", command=self.apagarE)
        self.buttonApagar5.place(
        x=200,
        y=550,
        width=130.0,
        height=30.0
        )

        self.buttonEncender6 = tk.Button(master=panel_principal, text="Encender", activebackground="#84E184", command=self.encenderF)
        self.buttonEncender6.place(
        x=350,
        y=550,
        width=130.0,
        height=30.0
        )
        
        self.buttonApagar6 = tk.Button(master=panel_principal, text="Apagar", activebackground="#E84B4F", command=self.apagarF)
        self.buttonApagar6.place(
        x=480,
        y=550,
        width=130.0,
        height=30.0
        )
        self.buttonApagarG.config(state=tk.DISABLED)
        self.buttonEncenderG.config(state=tk.DISABLED)
        # ---------------------------- Sliders -----------------------------
        #slider general
        # self.sliderg = ttk.Scale(master=panel_principal, from_=30, to_=100, length=260, takefocus=False, command=self.intensidadG, style='TScale')
        self.sliderg = tk.Scale(master=panel_principal, from_=0,to=100, orient=tk.HORIZONTAL,relief=tk.FLAT,
                        width=5,length=254,background="#C3CEDA")
        self.sliderg.place(x=70 , y=280)

        #slider 1
        self.slider1 = tk.Scale(master=panel_principal, from_=0,to=100, orient=tk.HORIZONTAL,relief=tk.FLAT,
                        width=5,length=254,background="#C3CEDA", command = self.intensidadA)
        self.slider1.place(x=70 , y=400)

        # slider 2
        self.slider2 = tk.Scale(master=panel_principal, from_=0,to=100, orient=tk.HORIZONTAL,relief=tk.FLAT,
                        width=5,length=254,background="#C3CEDA", command = self.intensidadB)
        self.slider2.place(x=350 , y=400)

        # slider 3
        self.slider3 = tk.Scale(master=panel_principal, from_=0,to=100, orient=tk.HORIZONTAL,relief=tk.FLAT,
                        width=5,length=254,background="#C3CEDA", command = self.intensidadC)
        self.slider3.place(x=70 , y=490)

        # slider 4
        self.slider4 = tk.Scale(master=panel_principal, from_=0,to=100, orient=tk.HORIZONTAL,relief=tk.FLAT,
                        width=5,length=254,background="#C3CEDA", command = self.intensidadD)
        self.slider4.place(x=350 , y=490)

        # slider 5
        self.slider5 = tk.Scale(master=panel_principal, from_=0,to=100, orient=tk.HORIZONTAL,relief=tk.FLAT,
                        width=5,length=254,background="#C3CEDA", command = self.intensidadE)
        self.slider5.place(x=70 , y=580)

        # slider 6
        self.slider6 = tk.Scale(master=panel_principal, from_=0,to=100, orient=tk.HORIZONTAL,relief=tk.FLAT,
                        width=5,length=254,background="#C3CEDA", command = self.intensidadF)
        self.slider6.place(x=350 , y=580)

        # ------------ Verificación de encendido con variables compartidas --------
        # if Formularios.variables_compartidas.modulos["state_modg"] == False:
        #     self.apagarG()
        # else:
        #     self.encenderG()
        if Formularios.variables_compartidas.modulos["state_mod1"] == False:
            self.apagar()
        else:
            self.encender()
        if Formularios.variables_compartidas.modulos["state_mod2"] == False:
            self.apagarB()
        else:
            self.encenderB()
        if Formularios.variables_compartidas.modulos["state_mod3"] == False:
            self.apagarC()
        else:
            self.encenderC()
        if Formularios.variables_compartidas.modulos["state_mod4"] == False:
            self.apagarD()
        else:
            self.encenderD()
        if Formularios.variables_compartidas.modulos["state_mod5"] == False:
            self.apagarE()
        else:
            self.encenderE()
        if Formularios.variables_compartidas.modulos["state_mod6"] == False:
            self.apagarF()
        else:
            self.encenderF()

        # ---------------- gráficas en el mismo form------------------
        def update(data,new_data):
                old_data = max(0,len(data)-len(new_data)) 
                data_update = np.concatenate((data[-old_data:],new_data)) #concatena el valor o los valores agregados a new data
                return data_update
                
        self.voltage = tk.Label(master=panel_principal, text= "valores tensión")
        self.voltage.place(x=750, y= 500)
        self.current = tk.Label(master=panel_principal, text= "valores corriente")
        self.current.place(x=850, y= 500)
        self.power = tk.Label(master=panel_principal, text= "potencia")
        self.power.place(x=950, y= 500)
        
        def grafica_tension(data,data2):
            global diego
            global moises
            while True:
                diego = data2
                moises = data
                for i in range(2):
                    new_data2 = ser.readline().decode().strip() #lee el valor de arduino
                    if new_data2.startswith("V:"): #diferencia si esta leyendo tensión o corriente
                        new_data2= [float(new_data2.split(":")[1])]
                # Update the plot with the new data  
                        data2 = update(data2,new_data2)  #meterle data viejo y el nuevo
                        self.voltage.config(text=data2[-1])
                        line2.set_ydata(data2)
                        fig2.canvas.draw() #dibuja
                        fig2.canvas.flush_events() #actualiza contenido de la grafica
                    elif new_data2.startswith("C:"):
                        new_data2= [float(new_data2.split(":")[1])]
                # Update the plot with the new data  
                        data = update(data,new_data2)  #meterle data viejo y el nuevo
                        self.current.config(text=data[-1])
                        self.power.config(text=data2[-1]*data[-1])
                        line.set_ydata(data)
                        fig.canvas.draw() #dibuja
                        fig.canvas.flush_events() #actualiza contenido de la grafica
        # Función para exportar datos a CSV

        def exportar_a_csv():
            # Crear un DataFrame con los datos de la gráfica
            coordenadas_x = np.linspace(0,59 ,60)  # Generar linspace para coordenadas x
            # Crear un DataFrame de pandas con los arreglos
            data_tension = pd.DataFrame({'Tiempo [s]': coordenadas_x, 'Tensión [V]': diego})
            data_corriente = pd.DataFrame({'Tiempo [s]': coordenadas_x, 'Corriente [A]': moises})
            # Nombre del archivo CSV
            nombre_archivo = "datos_tension.csv"
            nombre_archivo2 = "datos_corriente.csv"
            # Guardar el DataFrame en un archivo CSV
            data_tension.to_csv(nombre_archivo, index=False)
            data_corriente.to_csv(nombre_archivo2, index=False)

        self.tabControl = ttk.Notebook(master = panel_principal) 
        

        self.tab1 = ttk.Frame(self.tabControl) 
        self.tab2 = ttk.Frame(self.tabControl) 
        
        self.tabControl.add(self.tab1, text ='Tensión') 
        self.tabControl.add(self.tab2, text ='Corriente') 
        # self.tabControl.pack(expand = 1, fill ="both") 
        self.tabControl.place(x=680,y=50)
        
        fig = plt.figure(figsize=(4,4), dpi=100)
        ax = fig.add_subplot(1,1,1)
        plt.ylim([0,1])
        plt.xlim([0,60]) 
         #graficar el tab 2
         #graficar en el tab 1
        fig2 = plt.figure(figsize=(4,4), dpi=100)
        ax2 = fig2.add_subplot(1,1,1)
        plt.ylim([0,35])
        plt.xlim([0,60]) 
        self.iv_curve = FigureCanvasTkAgg(fig2, master = self.tab1)
        self.iv_curve.draw() 
        self.iv_curve.get_tk_widget().pack() 

        self.iv_curve2 = FigureCanvasTkAgg(fig, master = self.tab2)
        self.iv_curve2.draw() 
        self.iv_curve2.get_tk_widget().pack() 
        data = [0]*60
        data2 = [0]*60
        line, = ax.plot(data)# declarar un objeto que se llama linea que es opropio de la libreria matplolib, o sea poner la linea en el plot
        line2, = ax2.plot(data2)
        ax.set_xlabel('Tiempo (s)')
        ax.set_ylabel("Corriente")
        ax.set_title("Datos en tiempo real")
        ax.legend(['Corriente'],loc="upper right")

        ax2.set_xlabel('Tiempo (s)')
        ax2.set_ylabel("Tensión")
        ax2.set_title("Datos en tiempo real")
        ax2.legend(['Tensión'],loc="upper right")
        boton_exportar = tk.Button(panel_principal, text="Exportar a CSV", command=exportar_a_csv)
        boton_exportar.place(x=790,y=540)
        thread2 = threading.Thread(target=grafica_tension(data,data2))
        thread2.start()


        # self.slider1.bind("<B1-Motion>", ) #llama a la funcion actualizar valor mientras se mueve
        # self.slider1.bind("<ButtonRelease-1>", self.intensidadA) #llama a la funcion cuando se deja de mover
        # self.slider2.bind("<ButtonRelease-1>", self.intensidadA) #llama a la funcion cuando se deja de mover
        # self.slider3.bind("<ButtonRelease-1>", self.intensidadA) #llama a la funcion cuando se deja de mover
        # self.slider4.bind("<ButtonRelease-1>", self.intensidadA) #llama a la funcion cuando se deja de mover
        # self.slider5.bind("<ButtonRelease-1>", self.intensidadA) #llama a la funcion cuando se deja de mover
        # self.slider6.bind("<ButtonRelease-1>", self.intensidadA) #llama a la funcion cuando se deja de mover
    # ---------------------- Funciones para los sliders ----------------------

    def intensidadG(self, event):
        event = self.sliderg.get()
        Formularios.variables_compartidas.sliders["sliderG_val"] = event
        self.guardar_estado()
        
        
        

    def intensidadA(self, event):
        event = self.slider1.get()
        Formularios.variables_compartidas.sliders["slider1_val"] = event
        self.guardar_estado()
        event = self.update_value(event)
        event = "$SA"+str(event) + '\n'
        ser.write(event.encode())

    def intensidadB(self, event):
        event = self.slider2.get()
        Formularios.variables_compartidas.sliders["slider2_val"] = event
        self.guardar_estado()
        event = self.update_value(event)
        event = "$SB"+str(event) + '\n'
        ser.write(event.encode())

    def intensidadC(self, event):
        event = self.slider3.get()
        Formularios.variables_compartidas.sliders["slider3_val"] = event
        self.guardar_estado()
        event = self.update_value(event)
        event = "$SC"+str(event) + '\n'
        ser.write(event.encode())
    
    def intensidadD(self, event):
        event = self.slider4.get()
        Formularios.variables_compartidas.sliders["slider4_val"] = event
        self.guardar_estado()
        event = self.update_value(event)
        event = "$SD"+str(event) + '\n'
        ser.write(event.encode())

    def intensidadE(self, event):
        event = self.slider5.get()
        Formularios.variables_compartidas.sliders["slider5_val"] = event
        self.guardar_estado()
        event = self.update_value(event)
        event = "$SE"+str(event) + '\n'
        ser.write(event.encode())

    def intensidadF(self, event):
        event = self.slider6.get()
        Formularios.variables_compartidas.sliders["slider6_val"] = event
        self.guardar_estado()
        event = self.update_value(event)
        event = "$SF"+str(event) + '\n'
        ser.write(event.encode())

    # ---------------------- Manejo grupal ---------------------------------
    def enable_module(self):
        if self.var.get() == 1:  # Si el checkbox está marcado
            self.buttonEncenderG.config(state=tk.NORMAL)
            self.buttonApagarG.config(state=tk.DISABLED)
            self.sliderg["state"]=tk.NORMAL

            self.buttonEncender1.config(state=tk.DISABLED)
            self.buttonApagar1.config(state=tk.DISABLED)
            self.slider1["state"]=tk.DISABLED
            self.buttonEncender2.config(state=tk.DISABLED)
            self.buttonApagar2.config(state=tk.DISABLED)
            self.slider2["state"]=tk.DISABLED
            self.buttonEncender3.config(state=tk.DISABLED)
            self.buttonApagar3.config(state=tk.DISABLED)
            self.slider3["state"]=tk.DISABLED
            self.buttonEncender4.config(state=tk.DISABLED)
            self.buttonApagar4.config(state=tk.DISABLED)
            self.slider4["state"]=tk.DISABLED
            self.buttonEncender5.config(state=tk.DISABLED)
            self.buttonApagar5.config(state=tk.DISABLED)
            self.slider5["state"]=tk.DISABLED
            self.buttonEncender6.config(state=tk.DISABLED)
            self.buttonApagar6.config(state=tk.DISABLED)
            self.slider6["state"]=tk.DISABLED
        else:  # Si el checkbox está desmarcado
            self.buttonEncenderG.config(state=tk.DISABLED)
            self.buttonApagarG.config(state=tk.DISABLED)
            self.sliderg["state"]=tk.DISABLED 

            self.buttonEncender1.config(state=tk.NORMAL)
            self.buttonApagar1.config(state=tk.DISABLED)
            self.slider1["state"]=tk.NORMAL
            self.buttonEncender2.config(state=tk.NORMAL)
            self.buttonApagar2.config(state=tk.DISABLED)
            self.slider2["state"]=tk.NORMAL
            self.buttonEncender3.config(state=tk.NORMAL)
            self.buttonApagar3.config(state=tk.DISABLED)
            self.slider3["state"]=tk.NORMAL
            self.buttonEncender4.config(state=tk.NORMAL)
            self.buttonApagar4.config(state=tk.DISABLED)
            self.slider4["state"]=tk.NORMAL
            self.buttonEncender5.config(state=tk.NORMAL)
            self.buttonApagar5.config(state=tk.DISABLED)
            self.slider5["state"]=tk.NORMAL 
            self.buttonEncender6.config(state=tk.NORMAL)
            self.buttonApagar6.config(state=tk.DISABLED)
            self.slider6["state"]=tk.NORMAL
    #---------------------- Funciones de apagado y encendido ----------------------
    def apagarG(self):
        self.buttonEncenderG["state"]=tk.NORMAL #habilita boton encender
        self.buttonApagarG["state"]=tk.DISABLED # desabilita el boton apagar
        self.sliderg.set(0)
        self.intensidadG(0)
        self.sliderg["state"]=tk.DISABLED #desabilita slider
        self.modulo1.config(image=self.imagen_transparente_tk)
        self.modulo1.place(x=0,y=0)
        self.modulo2.config(image=self.imagen_transparente_tk)
        self.modulo2.place(x=0,y=0)
        self.modulo3.config(image=self.imagen_transparente_tk)
        self.modulo3.place(x=0,y=0)
        self.modulo4.config(image=self.imagen_transparente_tk)
        self.modulo4.place(x=0,y=0)
        self.modulo5.config(image=self.imagen_transparente_tk)
        self.modulo5.place(x=0,y=0)
        self.modulo6.config(image=self.imagen_transparente_tk)
        self.modulo6.place(x=0,y=0)
        
        Formularios.variables_compartidas.modulos["state_modg"] = False
        Formularios.variables_compartidas.verificador["g"] = 0
        self.guardar_estado()
        # event= str(self.slider1.get()) + '\n'
        # ser.write(event.encode())

    def apagar(self):
        self.buttonEncender1["state"]=tk.NORMAL #habilita boton encender
        self.buttonApagar1["state"]=tk.DISABLED # desabilita el boton apagar
        self.slider1.set(0)
        self.intensidadA(0)
        self.slider1["state"]=tk.DISABLED #desabilita slider
        self.modulo1.config(image=self.imagen_transparente_tk)
        self.modulo1.place(x=0,y=0)
        
        Formularios.variables_compartidas.modulos["state_mod1"] = False
        Formularios.variables_compartidas.verificador["1"] = 0
        self.guardar_estado()
        event= str(self.slider1.get()) + '\n'
        ser.write(event.encode())

    def apagarB(self):
        self.buttonEncender2["state"]=tk.NORMAL #habilita boton encender
        self.buttonApagar2["state"]=tk.DISABLED # desabilita el boton apagar
        self.slider2.set(0)
        self.intensidadB(0)
        self.slider2["state"]=tk.DISABLED #desabilita slider
        self.modulo2.config(image=self.imagen_transparente_tk)
        self.modulo2.place(x=0,y=0)

        Formularios.variables_compartidas.modulos["state_mod2"] = False
        Formularios.variables_compartidas.verificador["2"] = 0
        self.guardar_estado()
        event= str(self.slider2.get()) + '\n'
        ser.write(event.encode())

    def apagarC(self):
        self.buttonEncender3["state"]=tk.NORMAL #habilita boton encender
        self.buttonApagar3["state"]=tk.DISABLED # desabilita el boton apagar
        self.slider3.set(0)
        self.intensidadC
        self.slider3["state"]=tk.DISABLED #desabilita slider
        self.modulo3.config(image=self.imagen_transparente_tk)
        self.modulo3.place(x=0,y=0)
        
        Formularios.variables_compartidas.modulos["state_mod3"] = False
        Formularios.variables_compartidas.verificador["3"] = 0
        self.guardar_estado()
        event= str(self.slider3.get()) + '\n'
        ser.write(event.encode())

    
    def apagarD(self):
        self.buttonEncender4["state"]=tk.NORMAL #habilita boton encender
        self.buttonApagar4["state"]=tk.DISABLED # desabilita el boton apagar
        self.slider4.set(0)
        self.intensidadD(0)
        self.slider4["state"]=tk.DISABLED #desabilita slider
        self.modulo4.config(image=self.imagen_transparente_tk)
        self.modulo4.place(x=0,y=0)
        
        Formularios.variables_compartidas.modulos["state_mod4"] = False
        Formularios.variables_compartidas.verificador["4"] = 0
        self.guardar_estado()
        event= str(self.slider4.get()) + '\n'        
        ser.write(event.encode())
    
    def apagarE(self):
        self.buttonEncender5["state"]=tk.NORMAL #habilita boton encender
        self.buttonApagar5["state"]=tk.DISABLED # desabilita el boton apagar
        self.slider5.set(0)
        self.intensidadE(0)
        self.slider5["state"]=tk.DISABLED #desabilita slider
        self.modulo5.config(image=self.imagen_transparente_tk)
        self.modulo5.place(x=0,y=0)
        
        Formularios.variables_compartidas.modulos["state_mod5"] = False
        Formularios.variables_compartidas.verificador["5"] = 0
        self.guardar_estado()
        event= str(self.slider5.get()) + '\n'
        ser.write(event.encode())

    def apagarF(self):
        self.buttonEncender6["state"]=tk.NORMAL #habilita boton encender
        self.buttonApagar6["state"]=tk.DISABLED # desabilita el boton apagar
        self.slider6.set(0)
        self.intensidadF(0)
        self.slider6["state"]=tk.DISABLED #desabilita slider
        self.modulo6.config(image=self.imagen_transparente_tk)
        self.modulo6.place(x=0,y=0)
        
        Formularios.variables_compartidas.modulos["state_mod6"] = False
        Formularios.variables_compartidas.verificador["6"] = 0
        self.guardar_estado()
        event= str(self.slider6.get()) + '\n'
        ser.write(event.encode())

    def encenderG(self): 
        self.buttonApagarG["state"]=tk.NORMAL #habiliad boton apagar
        self.buttonEncenderG["state"]=tk.DISABLED #desabilita boton apagar
        self.sliderg["state"]=tk.NORMAL # habilita slider
        if Formularios.variables_compartidas.verificador["g"] == 0:
                self.intensidadA(100)
                time.sleep(1)
                self.intensidadB(100)
                time.sleep(1)
                # self.encenderC()
                # time.sleep(0.1)
                # self.encenderD()
                # time.sleep(0.1)
                # self.encenderE()
                # time.sleep(0.1)
                # self.encenderF()
                # time.sleep(0.1)

                Formularios.variables_compartidas.verificador["g"] = 1
        elif Formularios.variables_compartidas.verificador["g"] == 1:
            self.sliderg.set(Formularios.variables_compartidas.sliders["sliderg_val"])
            self.intensidadG(Formularios.variables_compartidas.sliders["sliderg_val"])
        self.modulo1.config(image=self.mod1_imag)
        self.modulo1.place(x=227,y=60.5)
        self.modulo2.config(image=self.mod2_imag)
        self.modulo2.place(x=301.45,y=60.5)
        self.modulo3.config(image=self.mod3_imag)
        self.modulo3.place(x=377,y=60.5)
        self.modulo4.config(image=self.mod4_imag)
        self.modulo4.place(x=377,y=130)
        self.modulo5.config(image=self.mod5_imag)
        self.modulo5.place(x=301.45,y=130)
        self.modulo6.config(image=self.mod6_imag)
        self.modulo6.place(x=227,y=130)

        Formularios.variables_compartidas.modulos["state_mod1"] = True
        Formularios.variables_compartidas.modulos["state_mod2"] = True
        Formularios.variables_compartidas.modulos["state_mod3"] = True
        Formularios.variables_compartidas.modulos["state_mod4"] = True
        Formularios.variables_compartidas.modulos["state_mod5"] = True
        Formularios.variables_compartidas.modulos["state_mod6"] = True
        self.guardar_estado()
        # event= str(self.slider1.get()) + '\n'
        # ser.write(event.encode())

    def encender(self): 
        self.buttonApagar1["state"]=tk.NORMAL #habiliad boton apagar
        self.buttonEncender1["state"]=tk.DISABLED #desabilita boton apagar
        self.slider1["state"]=tk.NORMAL # habilita slider
        if Formularios.variables_compartidas.verificador["1"] == 0:
            self.slider1.set(100)
            self.intensidadA(100)
            Formularios.variables_compartidas.verificador["1"] = 1
        elif Formularios.variables_compartidas.verificador["1"] == 1:
            self.slider1.set(Formularios.variables_compartidas.sliders["slider1_val"])
            self.intensidadA(Formularios.variables_compartidas.sliders["slider1_val"])
        self.modulo1.config(image=self.mod1_imag)
        self.modulo1.place(x=227,y=60.5)

        Formularios.variables_compartidas.modulos["state_mod1"] = True
        self.guardar_estado()
        event= str(self.slider1.get()) + '\n'
        ser.write(event.encode())

    def encenderB(self): 
        self.buttonApagar2["state"]=tk.NORMAL #shabiliad boton apagar
        self.buttonEncender2["state"]=tk.DISABLED #desabilita boton apagar
        self.slider2["state"]=tk.NORMAL # habilita slider
        if Formularios.variables_compartidas.verificador["2"] == 0:
            self.slider2.set(100)
            self.intensidadB(100)
            Formularios.variables_compartidas.verificador["2"] = 1
        elif Formularios.variables_compartidas.verificador["2"] == 1:
            self.slider2.set(Formularios.variables_compartidas.sliders["slider2_val"])
            self.intensidadB(Formularios.variables_compartidas.sliders["slider2_val"])
        self.modulo2.config(image=self.mod2_imag)
        self.modulo2.place(x=301.45,y=60.5)

        Formularios.variables_compartidas.modulos["state_mod2"] = True
        self.guardar_estado()
        event= str(self.slider2.get()) + '\n'
        ser.write(event.encode())

    def encenderC(self): 
        self.buttonApagar3["state"]=tk.NORMAL #habiliad boton apagar
        self.buttonEncender3["state"]=tk.DISABLED #desabilita boton apagar
        self.slider3["state"]=tk.NORMAL # habilita slider
        if Formularios.variables_compartidas.verificador["3"] == 0:
            self.slider3.set(100)
            self.intensidadC(100)
            Formularios.variables_compartidas.verificador["3"] = 1
        elif Formularios.variables_compartidas.verificador["3"] == 1:
            self.slider3.set(Formularios.variables_compartidas.sliders["slider3_val"])
            self.intensidadC(Formularios.variables_compartidas.sliders["slider3_val"])
        self.modulo3.config(image=self.mod3_imag)
        self.modulo3.place(x=377,y=60.5)
        
        Formularios.variables_compartidas.modulos["state_mod3"] = True
        self.guardar_estado()
        event= str(self.slider2.get()) + '\n'
        ser.write(event.encode())

    def encenderD(self): 
        self.buttonApagar4["state"]=tk.NORMAL #habiliad boton apagar
        self.buttonEncender4["state"]=tk.DISABLED #desabilita boton apagar
        self.slider4["state"]=tk.NORMAL # habilita slider
        if Formularios.variables_compartidas.verificador["4"] == 0:
            self.slider4.set(100)
            self.intensidadD(100)
            Formularios.variables_compartidas.verificador["4"] = 1
        elif Formularios.variables_compartidas.verificador["4"] == 1:
            self.slider4.set(Formularios.variables_compartidas.sliders["slider4_val"])
            self.intensidadD(Formularios.variables_compartidas.sliders["slider4_val"])
        self.modulo4.config(image=self.mod4_imag)
        self.modulo4.place(x=377,y=130)
        
        Formularios.variables_compartidas.modulos["state_mod4"] = True
        self.guardar_estado()
        event= str(self.slider4.get()) + '/n'
        ser.write(event.encode())
    
    def encenderE(self): 
        self.buttonApagar5["state"]=tk.NORMAL #habiliad boton apagar
        self.buttonEncender5["state"]=tk.DISABLED #desabilita boton apagar
        self.slider5["state"]=tk.NORMAL # habilita slider
        if Formularios.variables_compartidas.verificador["5"] == 0:
            self.slider5.set(100)
            self.intensidadE(100)
            Formularios.variables_compartidas.verificador["5"] = 1
        elif Formularios.variables_compartidas.verificador["5"] == 1:
            self.slider5.set(Formularios.variables_compartidas.sliders["slider5_val"])
            self.intensidadE(Formularios.variables_compartidas.sliders["slider5_val"])
        self.modulo5.config(image=self.mod5_imag)
        self.modulo5.place(x=301.45,y=130)
        
        Formularios.variables_compartidas.modulos["state_mod5"] = True
        self.guardar_estado()
        event= str(self.slider5.get()) + '/n'
        ser.write(event.encode())

    def encenderF(self): 
        self.buttonApagar6["state"]=tk.NORMAL #habiliad boton apagar
        self.buttonEncender6["state"]=tk.DISABLED #desabilita boton apagar
        self.slider6["state"]=tk.NORMAL # habilita slider
        if Formularios.variables_compartidas.verificador["6"] == 0:
            self.slider6.set(100)
            self.intensidadF(100)
            Formularios.variables_compartidas.verificador["6"] = 1
        elif Formularios.variables_compartidas.verificador["6"] == 1:
            self.slider6.set(Formularios.variables_compartidas.sliders["slider6_val"])
            self.intensidadF(Formularios.variables_compartidas.sliders["slider6_val"])
        self.modulo6.config(image=self.mod6_imag)
        self.modulo6.place(x=227,y=130)

        
        Formularios.variables_compartidas.modulos["state_mod6"] = True
        self.guardar_estado()
        event= str(self.slider6.get()) + '/n'
        ser.write(event.encode())
     
    # --------- Funciones para guardar y actualizar estado ---------------
    def guardar_estado(self):
        # Variables adicionales que deseas guardar
        variables = {
            "modulos": Formularios.variables_compartidas.modulos,
            "sliders": Formularios.variables_compartidas.sliders,
            "verificador": Formularios.variables_compartidas.verificador
            # Agrega más variables aquí según sea necesario
        }

        # Guardar el estado en el archivo
        with open('./Formularios/variables_compartidas.py', 'w') as file:
            for key, value in variables.items():
                file.write(f"{key} = {value}\n")

    def update_value(self, event):
        value = event
        mapped_value = 150 - (value * 1.49)
        # print(mapped_value)
        return mapped_value

class FormularioGraficasDesign():
    #Funciones necesarias
    variable_booleana = True #declaramos la variable booleana como global dentro de la clase

    def __init__(self, panel_principal):
        # try:
        #     #global ser
        #     #self.ser = serial.Serial('/dev/ttyACM1',9600) #puerto serie
        #     self.ser = serial.Serial('COM13',9600) #puerto serie en pc
        # except:
        #     print("No se pudo conectar el puerto serie")
        
        def update(data,new_data):
            old_data = max(0,len(data)-len(new_data)) 
            data_update = np.concatenate((data[-old_data:],new_data)) #concatena el valor o los valores agregados a new data
            return data_update
        
        # def on_tab_change(event):
        #     FormularioGraficasDesign.variable_booleana = not FormularioGraficasDesign.variable_booleana
        #     print("Evento de cambio de pestaña detectado.")
        #     print("Variable booleana ahora es:", FormularioGraficasDesign.variable_booleana)


        # def grafica_corriente(data):
        #     global diego
        #     diego = data
        #     while True:
        #         print("Holiwis")
        #         for i in range(2):
        #             new_data = ser.readline().decode().strip() #lee el valor de arduino
        #             if new_data.startswith("C:"): #diferencia si esta leyendo tensión o corriente
        #                 new_data= [float(new_data.split(":")[1])]
        #         # Update the plot with the new data  
        #                 data = update(data,new_data)  #meterle data viejo y el nuevo
        #                 line.set_ydata(data)
        #                 fig.canvas.draw() #dibuja
        #                 fig.canvas.flush_events() #actualiza contenido de la grafica

        def grafica_tension(data,data2):
            global diego
            diego = data2
            while True:
                for i in range(2):
                    # new_data2 = ser.readline().decode().strip() #lee el valor de arduino
                    if new_data2.startswith("V:"): #diferencia si esta leyendo tensión o corriente
                        new_data2= [float(new_data2.split(":")[1])]
                # Update the plot with the new data  
                        data2 = update(data2,new_data2)  #meterle data viejo y el nuevo
                        line2.set_ydata(data2)
                        fig2.canvas.draw() #dibuja
                        fig2.canvas.flush_events() #actualiza contenido de la grafica
                    elif new_data2.startswith("C:"):
                        new_data2= [float(new_data2.split(":")[1])]
                # Update the plot with the new data  
                        data = update(data,new_data2)  #meterle data viejo y el nuevo
                        line.set_ydata(data)
                        fig.canvas.draw() #dibuja
                        fig.canvas.flush_events() #actualiza contenido de la grafica

        # Función para exportar datos a CSV
        def exportar_a_csv():
            # Crear un DataFrame con los datos de la gráfica
            coordenadas_x = np.linspace(0, 99,100)  # Generar linspace para coordenadas x
            # Crear un DataFrame de pandas con los arreglos
            data = pd.DataFrame({'Tiempo [s]': coordenadas_x, 'Tensión [V]': diego})
            # Nombre del archivo CSV
            nombre_archivo = "datos_pandas.csv"
            # Guardar el DataFrame en un archivo CSV
            data.to_csv(nombre_archivo, index=False)


        self.tabControl = ttk.Notebook(panel_principal) 
        
        self.tab1 = ttk.Frame(self.tabControl) 
        self.tab2 = ttk.Frame(self.tabControl) 
        
        self.tabControl.add(self.tab1, text ='Tensión') 
        self.tabControl.add(self.tab2, text ='Corriente') 
        # self.tabControl.pack(expand = 1, fill ="both") 
        self.tabControl.place(x=300,y=100)
        
        fig = plt.figure(figsize=(4,3), dpi=100)
        ax = fig.add_subplot(1,1,1)
        plt.ylim([0,1])
        plt.xlim([0,100]) 
         #graficar el tab 2
         #graficar en el tab 1
        fig2 = plt.figure(figsize=(4,3), dpi=100)
        ax2 = fig2.add_subplot(1,1,1)
        plt.ylim([0,35])
        plt.xlim([0,100]) 
        self.iv_curve = FigureCanvasTkAgg(fig2, master = self.tab1)
        self.iv_curve.draw() 
        self.iv_curve.get_tk_widget().pack() 

        self.iv_curve2 = FigureCanvasTkAgg(fig, master = self.tab2)
        self.iv_curve2.draw() 
        self.iv_curve2.get_tk_widget().pack() 
        data = [0]*60
        data2 = [0]*60
        line, = ax.plot(data)# declarar un objeto que se llama linea que es opropio de la libreria matplolib, osea poner la linea en el plot
        line2, = ax2.plot(data2)
        ax.set_xlabel('Tiempo (s)')
        ax.set_ylabel("Corriente")
        ax.set_title("Datos en tiempo real")
        ax.legend(['Corriente'],loc="upper right")

        ax2.set_xlabel('Tiempo (s)')
        ax2.set_ylabel("Tensión")
        ax2.set_title("Datos en tiempo real")
        ax2.legend(['Tensión'],loc="upper right")
        boton_exportar = tk.Button(panel_principal, text="Exportar a CSV", command=exportar_a_csv)
        boton_exportar.pack()
        thread2 = threading.Thread(target=grafica_tension(data,data2))
        thread2.start()
